package com.example.qrcodeexample.qrcodedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QrcodedemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(QrcodedemoApplication.class, args);
    }


}
